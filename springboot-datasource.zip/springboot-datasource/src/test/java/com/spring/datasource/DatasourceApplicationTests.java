package com.spring.datasource;

import com.spring.datasource.bean.Info;
import com.spring.datasource.bean.User;
import com.spring.datasource.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.List;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class DatasourceApplicationTests {

    @Resource
    private UserService userService;

    @Test
    public void contextLoads() {
            List<Info> defInfo = this.userService.getDefInfo();
        log.info("默认数据库返回: {}", defInfo);

    }

    @Test
    public void contextLoads2() {
        List<User> bizInfo = this.userService.getBizInfo();
        log.info("多数据源数据库返回 ： {}", bizInfo);
    }


}
