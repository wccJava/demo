package com.spring.datasource.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.spring.datasource.bean.Info;
import com.spring.datasource.bean.User;
import com.spring.datasource.info.DataSource;
import com.spring.datasource.info.DbEnum;
import com.spring.datasource.mapper.InfoMapper;
import com.spring.datasource.mapper.UserMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wuchaocheng
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class UserService {

    @Resource
    private UserMapper userMapper;
    @Resource
    private InfoMapper infoMapper;

    @DataSource(name = DbEnum.DATA_SOURCE_BIZ)
    public List<User> getBizInfo() {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        return this.userMapper.selectList(queryWrapper);
    }

    public List<Info> getDefInfo() {
        QueryWrapper<Info> queryWrapper = new QueryWrapper<>();
        return this.infoMapper.selectList(queryWrapper);
    }

}
