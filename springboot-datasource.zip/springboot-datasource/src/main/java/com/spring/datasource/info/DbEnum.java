package com.spring.datasource.info;

/**
 * 数据源名称
 *
 * @author wuchaocheng
 */
public interface DbEnum {
    /**
     * 核心数据源
     */
    String DATA_SOURCE_CORE ="dataSourceCore";
    /**
     * 其他业务的数据源
     */
    String DATA_SOURCE_BIZ = "dataSourceBiz";

}
