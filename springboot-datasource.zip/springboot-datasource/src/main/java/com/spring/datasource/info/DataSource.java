package com.spring.datasource.info;

import java.lang.annotation.*;

/**
 * 自定义一个注解，用来在Service方法上面注解使用哪个数据源
 *
 * @author wuchaohcheng
 */
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface DataSource {

    String name() default "";
}
